#include "DacOut.h"

// initialize statics

float DacOutAttenuated::FixedGain = 1.0;
