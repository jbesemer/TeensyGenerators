#pragma once

#include "Waveform.h"

// A UniformWaveform is a sequence of levels of uniform duration

class UniformWaveform : public Waveform
{
protected:
	int* Samples;	// array of sample values
	ulong Duration;	// duration of each sample

	UniformWaveform( UniformWaveform* waveform )
		: UniformWaveform( waveform->Samples, waveform->Count, waveform->Duration )
	{
	}

public:

	// allocate space for samples to be initialized in by caller
	UniformWaveform( int count, ulong duration );

	// caller provides space for samples and fills them in
	UniformWaveform( int* samples, int count, ulong duration );

	int* GetSamples(){ return Samples; }
	ulong GetDuration(){ return Duration; }
	virtual ulong  CycleTime() { return Duration*Count; }

	virtual void Play( AnalogWriter* writer );

	void Set( int index, int sample );

	virtual String ToString() { return "UniformWaveform"; }
	void Print();
};
