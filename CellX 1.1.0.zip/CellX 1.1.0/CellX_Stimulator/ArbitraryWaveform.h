#pragma once

#include "Waveform.h"

// An ArbitraryWaveform is a sequence of Samples,
//	each a level of arbitrary duration

class ArbitraryWaveform : public Waveform
{
protected:
	Sample* Samples;	// array of Samples (value, duration pairs)

	ArbitraryWaveform();

public:
	// allocate space for samples to be initialized in by caller
	ArbitraryWaveform( int count );

	// caller provides space for samples and fills them in
	ArbitraryWaveform( Sample* samples, int count );

	virtual ulong  CycleTime(){
		long duration = 0;
		for( int i = 0; i < Count; i++ )
			duration += Samples[ i ].Duration;
		return duration;
	}

	virtual void Play( AnalogWriter* writer );

	void Set( int index, ulong duration, int value );

	virtual String ToString() { return "ArbitraryWaveform"; }
	void Print();
};
