#pragma once
#include "Config.h"
#include "ToggleMode.h"
#include "QuadMux.h"
#include "AnalogWriterMux.h"

class CellX_Demo : public ToggleMode
{
protected:
	int Index;
	AnalogWriterMux* MuxWriter;

public:
	CellX_Demo( AnalogWriterMux* aMux, int buttonPin )
		: ToggleMode( buttonPin )
	{
		MuxWriter = aMux;
	}

	// OLD STYLE
	virtual void Loop();		// called from main loop; override implements mode when Active
	virtual void Startup();		// override implements when mode toggles on
	virtual void Shutdown();	// override implements when mode toggles off

	// NEW STYLE (called from old style)
	virtual int Cycle();		// called from main loop; override implements mode when Active
	int PausingCycle();
	void NextChannelCycle();
	int PlayCycle( Waveform* waveform );
	void TurnOffCycle();
};

extern int CellX_Demo_Dacs[];
extern int CellX_Demo_Leds[];
extern int CellX_Demo_DacCount;

// local methods

extern void ClearAll();
extern void ToggleKeyswitch();
extern void SetAllDmod( int value );


