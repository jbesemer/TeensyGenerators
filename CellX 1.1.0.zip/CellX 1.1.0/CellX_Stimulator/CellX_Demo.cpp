#include "CommandProcessing.h"
#include "CellX_Demo.h"
#include "StairWaveform.h"

#define NEW_STYLE 1

int CellX_Demo_Dacs[] = {
	LTC2636_DAC_A,
	LTC2636_DAC_B,
	LTC2636_DAC_C,
	LTC2636_DAC_D,
};

int CellX_Demo_Leds[] = {
	LED1,
	LED2,
	LED3,
	LED4,
};

int CellX_Demo_DacCount = sizeof( CellX_Demo_Dacs ) / sizeof( CellX_Demo_Dacs[ 0 ] );

const int SampleCount = 200;
const int WaveMax = 3686; // 4096 * 90%
const int StepSize = WaveMax / SampleCount;
const int OverallDuration = 200000; // uS
const int SampleDuration_us = OverallDuration / SampleCount;
const int StartupDelay = 3000;	// ms

StairWaveform RampUpWaveform( SampleCount, 0, StepSize, SampleDuration_us );
StairWaveform RampDownWaveform( SampleCount, WaveMax, -StepSize, SampleDuration_us );

bool PausingSelected = true;
bool IsPausing = false;
bool IsPlaying = false;

elapsedMicros ElapsedTimer;

enum CellX_Demo_States { Pausing, NextChannel, RampUp, RampDown, TurnOff };
CellX_Demo_States CurrentState;
CellX_Demo_States InitialState;


// called from main loop [operates ToggleMode]

void CellX_Demo::Loop(){
	// poll button, control Active, fire Startup and Shutdown events
	MainBlinker.Loop();
	ToggleMode::Loop();

	if( Active ) {
#if NEW_STYLE
		Cycle();
#else
		if( Index >= CellX_Demo_DacCount ) {
			Index = 0;
		}
		Serial.print( "CellX Demo Chan " );
		Serial.println( Index );

		int ledPin = CellX_Demo_Leds[ Index ];
		LedOn( ledPin );
		MuxWriter->SetAddr( CellX_Demo_Dacs[ Index ] );
		RampUpWaveform.Play( MuxWriter );	// synchronous -- plays entire waveform before returning
		RampDownWaveform.Play( MuxWriter );	// synchronous -- plays entire waveform before returning
		MuxWriter->WriteRaw( 0 );	// reset to 0 when waveform is done
		LedOff( ledPin );
		Index++;
#endif
	}
}

void CellX_Demo::Startup(){
	// test Active before calling base, to catch rising edge
	if( !Active ) {
		Serial.println( "CellX Demo Startup" );
		ClearAll();
		MuxWriter->Reset();
		SetAllDmod( 1 );
		ToggleKeyswitch();

		Index = 0;	// start with first DAQ
		IsPausing = false;
		IsPlaying = false;
		CurrentState 
			= PausingSelected
				? Pausing
				: NextChannel;
	}

	ToggleMode::Startup();
}

void CellX_Demo::Shutdown(){
	// test Active before calling base, to catch falling edge
	if( Active ) {
		Serial.println( "CellX Demo Shutdown" );
		MuxWriter->Reset();
		ClearAll();
		SetAllDmod( 0 );
		MainBlinker.SetPattern( 0x15, 10, 100 );    // blinks LED thrice per sec
	}

	ToggleMode::Shutdown();
}


void AdvanceToNextState(){
	switch( CurrentState ){
	case Pausing:	CurrentState = NextChannel; break;
	case NextChannel:	CurrentState = RampUp; break;
	case RampUp:	CurrentState = RampDown; break;
	case RampDown:	CurrentState = TurnOff; break;

	// the overall cycle repeats indefinitely,
	// but Pausing only happens once at startup
	case TurnOff:	CurrentState = InitialState; break;
	}
}

// called from Loop, only when Demo Active (so TODO: get rid of redundant test)

int CellX_Demo::Cycle(){
	if( Active ) {
		switch( CurrentState ){
		case Pausing:
			if( PausingCycle() )
				break;	// completed
			return 0;	// my safe word is "keep going"
		case NextChannel:
			NextChannelCycle();
			break;	// always completes
		case RampUp:
			if( PlayCycle( &RampUpWaveform ) )
				break;	// completed
			return 0;	// my safe word is "keep going"
		case RampDown:
			if( PlayCycle( &RampDownWaveform ) )
				break;	// completed
			return 0;	// my safe word is "keep going"
		case TurnOff:
			TurnOffCycle();
			break;	// always completes
		}

		// if we get here we advance to the next state
		AdvanceToNextState();
	}

	return 0;	// Continue Cycling
}

void CellX_Demo::NextChannelCycle(){
	if( Index >= CellX_Demo_DacCount ) {
		Index = 0;
	}
	Serial.print( "CellX Demo Chan " );
	Serial.println( Index );

	LedOn( CellX_Demo_Leds[ Index ] );
	MuxWriter->SetAddr( CellX_Demo_Dacs[ Index ] );
}

void CellX_Demo::TurnOffCycle(){
	MuxWriter->WriteRaw( 0 );	// output 0 when waveform is done
	LedOff( CellX_Demo_Leds[ Index ] );
	Index++;
}

int CellX_Demo::PlayCycle( Waveform* waveform ){
	if( !IsPlaying ){	// first time startup init
		Serial.print( "Begin Playing waveform, CycleTime: " );
		Serial.println( waveform->CycleTime() );
		IsPlaying = true;
		ElapsedTimer = 0;
	}

	if( ElapsedTimer < waveform->CycleTime() )
		return 0;	// need to wait more

	Serial.println( "Done Playing waveform" );
	IsPlaying = false;
	return 1;		// all done
}

int CellX_Demo::PausingCycle(){
	if( !IsPausing ){	// first time startup init
		Serial.println( "Pausing for CellX to complete initialization" );
		IsPausing = true;
		ElapsedTimer = 0;
		MainBlinker.SetPattern( 0x1, 2, 50 );
		return 0;
	}

	// while waiting, we say we're not done
	if( ElapsedTimer < StartupDelay )
		return 0;

	// startup timer has expired, so advance to next state
	Serial.println( "Done Pausing" );
	MainBlinker.SetPattern( 0x15, 10, 100 );    // blinks LED thrice per sec
	IsPausing = false;
	return 1;	// done pausing
}


void ClearAll(){
	for( int i = 0; i < CellX_Demo_DacCount; i++ )
		LedOff( CellX_Demo_Leds[ i ] );
}

void ToggleKeyswitch(){
	Serial.print( "Toggle KeyOn: OFF..." );
	digitalWrite( KeyOn, 0 );
	delay( 100 );
	Serial.println( " ON..." );
	digitalWrite( KeyOn, 1 );
}

void SetAllDmod( int value ){
	Serial.print( "Setting all DMODs" );
	Serial.println( ( value ? " ON" : "OFF" ) );
	digitalWrite( DMOD1, value );
	digitalWrite( DMOD2, value );
	digitalWrite( DMOD3, value );
	digitalWrite( DMOD4, value );
}



