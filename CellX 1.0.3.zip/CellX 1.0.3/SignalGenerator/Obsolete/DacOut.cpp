#include "DacOut.h"

// initialize its statics

uint DacOut::Max = 4095;
uint DacOut::MaxBits = 12;
float DacOut::MaxVolts = DAC_MAX_VOLTS;
float DacOut::MeterMaxVolts = METER_MAX_VOLTS;
uint DacOut::MeterMax = METER_MAX;


