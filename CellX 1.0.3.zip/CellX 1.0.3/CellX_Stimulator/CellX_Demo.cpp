#include "CommandProcessing.h"
#include "CellX_Demo.h"
#include "StairWaveform.h"

int CellX_Demo_Dacs[] = {
	LTC2636_DAC_A,
	LTC2636_DAC_B,
	LTC2636_DAC_C,
	LTC2636_DAC_D,
};

int CellX_Demo_Leds[] = {
	LED1,
	LED2,
	LED3,
	LED4,
};

void ClearAll(){
	for( int i = 0; i < CellX_Demo_DacCount; i++ )
		LedOff( CellX_Demo_Leds[ i ] );
}

int CellX_Demo_DacCount = sizeof( CellX_Demo_Dacs ) / sizeof( CellX_Demo_Dacs[ 0 ] );

const int SampleCount = 200;
const int WaveMax = 3686; // 4096 * 90%
const int StepSize = WaveMax / SampleCount;
const int OverallDuration = 200000; // uS
const int SampleDuration_us = OverallDuration / SampleCount;

StairWaveform RampUp( SampleCount, 0, StepSize, SampleDuration_us );
StairWaveform RampDown( SampleCount, WaveMax, -StepSize, SampleDuration_us );

void CellX_Demo::Loop(){
	ToggleMode::Loop();

	if( Active ) {
		if( Index >= CellX_Demo_DacCount ) {
			Index = 0;
		}
		Serial.print( "CellX Demo Chan " );
		Serial.println( Index );

		int ledPin = CellX_Demo_Leds[ Index ];
		LedOn( ledPin );
		MuxWriter->SetAddr( CellX_Demo_Dacs[ Index ] );
		RampUp.Play( MuxWriter );	// synchronous -- plays entire waveform before returning
		RampDown.Play( MuxWriter );	// synchronous -- plays entire waveform before returning
		MuxWriter->WriteRaw( 0 );	// reset to 0 when waveform is done
		LedOff( ledPin );
		Index++;
	}
}

void ToggleKeyswitch(){
	Serial.print( "Toggle KeyOn: OFF..." );
	digitalWrite( KeyOn, 0 );
	delay( 100 );
	Serial.println( " ON..." );
	digitalWrite( KeyOn, 1 );
}

void SetAllDmod( int value ){
	Serial.print( "Setting all DMODs" );
	Serial.println( ( value ? " ON" : "OFF" ) );
	digitalWrite( DMOD1, value );
	digitalWrite( DMOD2, value );
	digitalWrite( DMOD3, value );
	digitalWrite( DMOD4, value );
}

const int StartupDelay = 3000;	// ms

void CellX_Demo::Startup(){
	// test before calling base, to catch rising edge
	if( !Active ) {
		MainBlinker.SetPattern( 0x1, 2, 50 );
		Serial.println( "Pausing for CellX to complete initialization" );
		elapsedMillis wait;
		while( wait < StartupDelay ){
			MainBlinker.Loop();
		}
		MainBlinker.SetPattern( 0x15, 10, 100 );    // blinks LED thrice per sec

		//MainBlinker.SetPattern(0x1, 2, 50);
		Serial.println( "Starting CellX Demo" );
		ClearAll();
		Index = 0;	// start with first one
		MuxWriter->Reset();
		SetAllDmod( 1 );
		ToggleKeyswitch();
	}

	ToggleMode::Startup();
}

void CellX_Demo::Shutdown(){
	// test before calling base, to catch falling edge
	if( Active ) {
		Serial.println( "Stopping CellX Demo" );
		MuxWriter->Reset();
		ClearAll();
		SetAllDmod( 0 );
		MainBlinker.SetPattern(0x15, 10, 100);    // blinks LED thrice per sec
	}

	ToggleMode::Shutdown();
}

